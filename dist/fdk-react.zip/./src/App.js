import React, { useState, useLayoutEffect } from 'react';
import './App.css';
import HelloUser from './components/HelloUser'
import Order from './components/Order/Order';

const App = () => {

  const [loaded, setLoaded] = useState(false);
  const [child, setChild] = useState(<h3>App is loading</h3>)

  useLayoutEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://cdn.freshdev.io/assets/app-client@2.js';
    script.addEventListener('load', () => setLoaded(true));
    script.defer = true;
    document.head.appendChild(script);
  }, []);

  useLayoutEffect(() => {
    if (!loaded) return
    app.initialized().then((client) => {
      setChild((<Order client={client} />))
    })
  }, [loaded])

  return (
    <div>
      {child}
    </div>
  )
}

export default App;
