import React, { useState } from 'react'
import PropTypes from 'prop-types'
import { FwDataTable } from "@freshworks/crayons/react";

const HelloUser = (props) => {
  let data = {
    columns: [{
      "key": "name",
      "text": "Name"
    }, {
      "key": "group",
      "text": "Group"
    }, {
      "key": "role",
      "text": "Role"
    }],
    persons: [{
      "id": "1234",
      "name": "Alexander Goodman",
      "role": "Administrator",
      "group": "L1 Support"
    }, {
      "id": "2345",
      "name": "Ambrose Wayne",
      "role": "Supervisor",
      "group": "L1 Support"
    }, {
      "id": "3456",
      "name": "August hines",
      "role": "Agent",
      "group": "L1 support"
    }]
  };

  return (
    <FwDataTable columns={data.columns} rows={data.persons} label="Data Table 1" isSelectable>
    </FwDataTable>
  );
}

HelloUser.propTypes = {
  client: PropTypes.object
}
export default HelloUser
