import React, { useEffect } from 'react';
import Axios from '../../config/axiosConfig';

export default function Order (){

    useEffect(() => {
        try {
            handleOnLoadOrders();
        } catch (error) {
            
        }
    },[]);

    const handleOnLoadOrders = () => {
        try {
            console.log("here....")
            Axios.get(`/order/search`).then(orderResponse => {
                console.log(orderResponse)
            }).catch(error => {
                console.log(error);
            })
        } catch (error) {
            console.log(error);
        }
    }

    return(

        <div/>

    )

}